// Прокси между приложением AI Vils и BytePlus ModelArk. Ключ хранится только здесь.
// Запуск: ARK_API_KEY=... node server.js   (Node 18+, без зависимостей)
const http = require('http');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');
const path = require('path');
const APK = process.env.APK_FILE || path.join(__dirname, '..', 'site', 'ai-vils.apk');
const SITE = process.env.SITE_FILE || path.join(__dirname, '..', 'site', 'index.html');
const KEY = process.env.ARK_API_KEY;
const BASE = process.env.ARK_BASE || 'https://ark.ap-southeast.bytepluses.com/api/v3';
const MODELS = {
  'seedance-2.5': process.env.MODEL_25 || 'dreamina-seedance-2-5-260628',
  'seedance-1.0': process.env.MODEL_10 || 'seedance-1-0-pro-250528',
};
const MAX_SEC = { 'seedance-2.5': 30, 'seedance-1.0': 10 };
const DAILY_LIMIT = +(process.env.DAILY_LIMIT_PER_IP || 20); // защита вашего бюджета
const OUT = process.env.OUT_DIR || path.join(os.tmpdir(), 'aivils-out'); fs.mkdirSync(OUT, { recursive: true });
const WM = path.join(__dirname, 'watermark.png');
const jobs = new Map(); let chain = Promise.resolve();
setInterval(() => { for (const f of fs.readdirSync(OUT)) { const p = path.join(OUT, f); try { if (Date.now() - fs.statSync(p).mtimeMs > 24 * 3600e3) fs.rmSync(p, { recursive: true, force: true }); } catch {} } }, 3600e3);
const ff = a => new Promise((ok, no) => { const p = spawn('ffmpeg', ['-y', '-loglevel', 'error', ...a]); let e = ''; p.stderr.on('data', d => e += d); p.on('error', () => no(new Error('На сервере не установлен ffmpeg'))); p.on('close', c => c ? no(new Error(e.slice(-300))) : ok()); });
// Склейка частей и логотип: 5 с слева сверху, 5 с справа снизу, по кругу
async function render(id, ids) {
  const job = jobs.get(id), dir = fs.mkdtempSync(path.join(OUT, 'w-'));
  try {
    const parts = [];
    for (let i = 0; i < ids.length; i++) {
      const j = await (await ark('/contents/generations/tasks/' + encodeURIComponent(ids[i]))).json();
      if (!j.content?.video_url) throw new Error('Часть ' + (i + 1) + ' не готова');
      const f = path.join(dir, 'p' + i + '.mp4');
      fs.writeFileSync(f, Buffer.from(await (await fetch(j.content.video_url)).arrayBuffer())); parts.push(f);
      job.progress = Math.round((i + 1) / ids.length * 70);
    }
    const list = path.join(dir, 'list.txt'), joined = path.join(dir, 'joined.mp4');
    fs.writeFileSync(list, parts.map(f => "file '" + f + "'").join('\n'));
    await ff(['-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', joined]);
    job.progress = 80;
    const pos = "if(lt(mod(t,10),5),24,%s)";
    await ff(['-i', joined, '-i', WM, '-filter_complex', "[0:v][1:v]overlay=x='" + pos.replace('%s', 'W-w-24') + "':y='" + pos.replace('%s', 'H-h-24') + "'[v]",
      '-map', '[v]', '-map', '0:a?', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p', '-c:a', 'copy', '-movflags', '+faststart', path.join(OUT, id + '.mp4')]);
    job.status = 'done'; job.progress = 100;
  } catch (e) { job.status = 'error'; job.error = e.message; }
  fs.rmSync(dir, { recursive: true, force: true });
}
const hits = new Map();
setInterval(() => hits.clear(), 24 * 3600e3);

const ark = (path, opt = {}) => fetch(BASE + path, { ...opt, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + KEY } });
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type' }); res.end(JSON.stringify(obj)); };
const body = req => new Promise((ok, no) => { let b = '', n = 0; req.on('data', c => { n += c.length; if (n > 15e6) { no(new Error('big')); req.destroy(); } else b += c; }); req.on('end', () => ok(b)); });

http.createServer(async (req, res) => {
  try {
    if (req.method === 'OPTIONS') return send(res, 204, {});
    const u = new URL(req.url, 'http://x');
    if (req.method === 'POST' && u.pathname === '/api/generate') {
      const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
      const c = (hits.get(ip) || 0) + 1; hits.set(ip, c);
      if (c > DAILY_LIMIT) return send(res, 429, { error: 'Дневной лимит запросов исчерпан' });
      const { model, prompt, seconds, image } = JSON.parse(await body(req));
      if (!MODELS[model] || !prompt || prompt.length > 2000) return send(res, 400, { error: 'Неверные параметры' });
      const dur = Math.min(Math.max(+seconds || 5, 3), MAX_SEC[model]);
      const content = [{ type: 'text', text: prompt }];
      if (image) content.push({ type: 'image_url', image_url: { url: image }, role: 'first_frame' });
      const r = await ark('/contents/generations/tasks', { method: 'POST', body: JSON.stringify({
        model: MODELS[model], content, duration: dur, resolution: '720p', ratio: 'adaptive', return_last_frame: true }) });
      const j = await r.json();
      if (!r.ok) return send(res, 502, { error: j.error?.message || 'Ошибка сервиса' });
      return send(res, 200, { id: j.id, seconds: dur });
    }
    if (req.method === 'GET' && u.pathname === '/api/status') {
      const id = encodeURIComponent(u.searchParams.get('id') || '');
      const j = await (await ark('/contents/generations/tasks/' + id)).json();
      return send(res, 200, { status: j.status, video_url: j.content?.video_url, last_frame_url: j.content?.last_frame_url, error: j.error?.message });
    }
    if ((req.method === 'GET' || req.method === 'HEAD') && u.pathname === '/ai-vils.apk') {
      if (!fs.existsSync(APK)) return send(res, 404, { error: 'APK ещё не загружен' });
      res.writeHead(200, { 'Content-Type': 'application/vnd.android.package-archive', 'Content-Length': fs.statSync(APK).size, 'Content-Disposition': 'attachment; filename="AI-Vils.apk"', 'Access-Control-Allow-Origin': '*' });
      return req.method === 'HEAD' ? res.end() : fs.createReadStream(APK).pipe(res);
    }
    if (req.method === 'POST' && u.pathname === '/api/finish') {
      const { ids } = JSON.parse(await body(req));
      if (!Array.isArray(ids) || !ids.length || ids.length > 150 || ids.some(x => typeof x !== 'string')) return send(res, 400, { error: 'Неверные параметры' });
      const id = crypto.randomUUID(); jobs.set(id, { status: 'working', progress: 0 });
      chain = chain.then(() => render(id, ids));
      return send(res, 200, { id });
    }
    if (req.method === 'GET' && u.pathname === '/api/render') {
      const j = jobs.get(u.searchParams.get('id'));
      return j ? send(res, 200, { status: j.status, progress: j.progress, error: j.error, url: j.status === 'done' ? '/out/' + u.searchParams.get('id') + '.mp4' : undefined }) : send(res, 404, { error: 'Задача не найдена' });
    }
    if (req.method === 'GET' && /^\/out\/[\w-]+\.mp4$/.test(u.pathname)) {
      const f = path.join(OUT, path.basename(u.pathname));
      if (!fs.existsSync(f)) return send(res, 404, { error: 'Файл не найден или удалён' });
      res.writeHead(200, { 'Content-Type': 'video/mp4', 'Content-Length': fs.statSync(f).size, 'Content-Disposition': 'attachment; filename="AI-Vils.mp4"', 'Access-Control-Allow-Origin': '*' });
      return fs.createReadStream(f).pipe(res);
    }
    const ST = { '/manifest.webmanifest': 'application/manifest+json', '/sw.js': 'text/javascript', '/icon-192.png': 'image/png', '/icon-512.png': 'image/png' };
    if (req.method === 'GET' && ST[u.pathname]) { res.writeHead(200, { 'Content-Type': ST[u.pathname] }); return res.end(fs.readFileSync(path.join(path.dirname(SITE), u.pathname))); }
    if (req.method === 'GET' && u.pathname === '/') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(fs.readFileSync(SITE)); }
    send(res, 404, { error: 'Не найдено' });
  } catch (e) { send(res, 500, { error: 'Внутренняя ошибка' }); }
}).listen(process.env.PORT || 3000, () => console.log('AI Vils server запущен'));
